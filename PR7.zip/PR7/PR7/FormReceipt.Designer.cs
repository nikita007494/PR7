﻿namespace PR7
{
    partial class FormReceipt
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label labelReceiptTitle;
        private System.Windows.Forms.Label labelOrderNumber;
        private System.Windows.Forms.Label orderNumberLabel;
        private System.Windows.Forms.Label labelOrderDate;
        private System.Windows.Forms.Label orderDateLabel;
        private System.Windows.Forms.Label labelBookTitle;
        private System.Windows.Forms.Label bookTitleLabel;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.Label customerNameLabel;
        private System.Windows.Forms.Label labelOffice;
        private System.Windows.Forms.Label officeLabel;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.TextBox receiptTextBox;
        private System.Windows.Forms.Button printButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.GroupBox receiptGroupBox;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            labelReceiptTitle = new Label();
            labelOrderNumber = new Label();
            orderNumberLabel = new Label();
            labelOrderDate = new Label();
            orderDateLabel = new Label();
            labelBookTitle = new Label();
            bookTitleLabel = new Label();
            labelCustomerName = new Label();
            customerNameLabel = new Label();
            labelOffice = new Label();
            officeLabel = new Label();
            labelPrice = new Label();
            priceLabel = new Label();
            receiptTextBox = new TextBox();
            printButton = new Button();
            saveButton = new Button();
            closeButton = new Button();
            receiptGroupBox = new GroupBox();
            pictureBox1 = new PictureBox();
            receiptGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // labelReceiptTitle
            // 
            labelReceiptTitle.AutoSize = true;
            labelReceiptTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            labelReceiptTitle.ForeColor = Color.Red;
            labelReceiptTitle.Location = new Point(259, 28);
            labelReceiptTitle.Margin = new Padding(4, 0, 4, 0);
            labelReceiptTitle.Name = "labelReceiptTitle";
            labelReceiptTitle.Size = new Size(194, 24);
            labelReceiptTitle.TabIndex = 0;
            labelReceiptTitle.Text = "ЧЕК ПРЕДЗАКАЗА";
            // 
            // labelOrderNumber
            // 
            labelOrderNumber.AutoSize = true;
            labelOrderNumber.Location = new Point(35, 34);
            labelOrderNumber.Margin = new Padding(4, 0, 4, 0);
            labelOrderNumber.Name = "labelOrderNumber";
            labelOrderNumber.Size = new Size(85, 15);
            labelOrderNumber.TabIndex = 0;
            labelOrderNumber.Text = "Номер заказа:";
            // 
            // orderNumberLabel
            // 
            orderNumberLabel.AutoSize = true;
            orderNumberLabel.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            orderNumberLabel.Location = new Point(140, 34);
            orderNumberLabel.Margin = new Padding(4, 0, 4, 0);
            orderNumberLabel.Name = "orderNumberLabel";
            orderNumberLabel.Size = new Size(0, 15);
            orderNumberLabel.TabIndex = 1;
            // 
            // labelOrderDate
            // 
            labelOrderDate.AutoSize = true;
            labelOrderDate.Location = new Point(35, 64);
            labelOrderDate.Margin = new Padding(4, 0, 4, 0);
            labelOrderDate.Name = "labelOrderDate";
            labelOrderDate.Size = new Size(35, 15);
            labelOrderDate.TabIndex = 2;
            labelOrderDate.Text = "Дата:";
            // 
            // orderDateLabel
            // 
            orderDateLabel.AutoSize = true;
            orderDateLabel.Location = new Point(140, 64);
            orderDateLabel.Margin = new Padding(4, 0, 4, 0);
            orderDateLabel.Name = "orderDateLabel";
            orderDateLabel.Size = new Size(0, 15);
            orderDateLabel.TabIndex = 3;
            // 
            // labelBookTitle
            // 
            labelBookTitle.AutoSize = true;
            labelBookTitle.Location = new Point(35, 92);
            labelBookTitle.Margin = new Padding(4, 0, 4, 0);
            labelBookTitle.Name = "labelBookTitle";
            labelBookTitle.Size = new Size(42, 15);
            labelBookTitle.TabIndex = 4;
            labelBookTitle.Text = "Книга:";
            // 
            // bookTitleLabel
            // 
            bookTitleLabel.AutoSize = true;
            bookTitleLabel.Location = new Point(140, 92);
            bookTitleLabel.Margin = new Padding(4, 0, 4, 0);
            bookTitleLabel.Name = "bookTitleLabel";
            bookTitleLabel.Size = new Size(0, 15);
            bookTitleLabel.TabIndex = 5;
            // 
            // labelCustomerName
            // 
            labelCustomerName.AutoSize = true;
            labelCustomerName.Location = new Point(35, 122);
            labelCustomerName.Margin = new Padding(4, 0, 4, 0);
            labelCustomerName.Name = "labelCustomerName";
            labelCustomerName.Size = new Size(49, 15);
            labelCustomerName.TabIndex = 6;
            labelCustomerName.Text = "Клиент:";
            // 
            // customerNameLabel
            // 
            customerNameLabel.AutoSize = true;
            customerNameLabel.Location = new Point(140, 122);
            customerNameLabel.Margin = new Padding(4, 0, 4, 0);
            customerNameLabel.Name = "customerNameLabel";
            customerNameLabel.Size = new Size(0, 15);
            customerNameLabel.TabIndex = 7;
            // 
            // labelOffice
            // 
            labelOffice.AutoSize = true;
            labelOffice.Location = new Point(35, 150);
            labelOffice.Margin = new Padding(4, 0, 4, 0);
            labelOffice.Name = "labelOffice";
            labelOffice.Size = new Size(85, 15);
            labelOffice.TabIndex = 8;
            labelOffice.Text = "Офис выдачи:";
            // 
            // officeLabel
            // 
            officeLabel.AutoSize = true;
            officeLabel.Location = new Point(140, 150);
            officeLabel.Margin = new Padding(4, 0, 4, 0);
            officeLabel.Name = "officeLabel";
            officeLabel.Size = new Size(0, 15);
            officeLabel.TabIndex = 9;
            // 
            // labelPrice
            // 
            labelPrice.AutoSize = true;
            labelPrice.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            labelPrice.Location = new Point(35, 178);
            labelPrice.Margin = new Padding(4, 0, 4, 0);
            labelPrice.Name = "labelPrice";
            labelPrice.Size = new Size(85, 15);
            labelPrice.TabIndex = 10;
            labelPrice.Text = "Стоимость:";
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            priceLabel.ForeColor = Color.Green;
            priceLabel.Location = new Point(140, 178);
            priceLabel.Margin = new Padding(4, 0, 4, 0);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new Size(0, 15);
            priceLabel.TabIndex = 11;
            // 
            // receiptTextBox
            // 
            receiptTextBox.Location = new Point(143, 477);
            receiptTextBox.Margin = new Padding(4);
            receiptTextBox.Multiline = true;
            receiptTextBox.Name = "receiptTextBox";
            receiptTextBox.ReadOnly = true;
            receiptTextBox.ScrollBars = ScrollBars.Vertical;
            receiptTextBox.Size = new Size(420, 131);
            receiptTextBox.TabIndex = 2;
            receiptTextBox.TextChanged += receiptTextBox_TextChanged;
            // 
            // printButton
            // 
            printButton.Location = new Point(143, 616);
            printButton.Margin = new Padding(4);
            printButton.Name = "printButton";
            printButton.Size = new Size(116, 34);
            printButton.TabIndex = 3;
            printButton.Text = "Печать";
            printButton.UseVisualStyleBackColor = true;
            printButton.Click += printButton_Click;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(294, 616);
            saveButton.Margin = new Padding(4);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(116, 34);
            saveButton.TabIndex = 4;
            saveButton.Text = "Сохранить";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += saveButton_Click;
            // 
            // closeButton
            // 
            closeButton.Location = new Point(445, 616);
            closeButton.Margin = new Padding(4);
            closeButton.Name = "closeButton";
            closeButton.Size = new Size(116, 34);
            closeButton.TabIndex = 5;
            closeButton.Text = "Закрыть";
            closeButton.UseVisualStyleBackColor = true;
            closeButton.Click += closeButton_Click;
            // 
            // receiptGroupBox
            // 
            receiptGroupBox.Controls.Add(labelOrderNumber);
            receiptGroupBox.Controls.Add(orderNumberLabel);
            receiptGroupBox.Controls.Add(labelOrderDate);
            receiptGroupBox.Controls.Add(orderDateLabel);
            receiptGroupBox.Controls.Add(labelBookTitle);
            receiptGroupBox.Controls.Add(bookTitleLabel);
            receiptGroupBox.Controls.Add(labelCustomerName);
            receiptGroupBox.Controls.Add(customerNameLabel);
            receiptGroupBox.Controls.Add(labelOffice);
            receiptGroupBox.Controls.Add(officeLabel);
            receiptGroupBox.Controls.Add(labelPrice);
            receiptGroupBox.Controls.Add(priceLabel);
            receiptGroupBox.Location = new Point(143, 63);
            receiptGroupBox.Margin = new Padding(4);
            receiptGroupBox.Name = "receiptGroupBox";
            receiptGroupBox.Padding = new Padding(4);
            receiptGroupBox.Size = new Size(420, 208);
            receiptGroupBox.TabIndex = 1;
            receiptGroupBox.TabStop = false;
            receiptGroupBox.Text = "Информация о заказе";
            receiptGroupBox.Enter += receiptGroupBox_Enter;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.spasibo_thank_you;
            pictureBox1.Location = new Point(143, 278);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(420, 192);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // FormReceipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(697, 679);
            Controls.Add(pictureBox1);
            Controls.Add(closeButton);
            Controls.Add(saveButton);
            Controls.Add(printButton);
            Controls.Add(receiptTextBox);
            Controls.Add(receiptGroupBox);
            Controls.Add(labelReceiptTitle);
            Margin = new Padding(4);
            Name = "FormReceipt";
            Text = "Чек предзаказа";
            receiptGroupBox.ResumeLayout(false);
            receiptGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
        private PictureBox pictureBox1;
    }
}