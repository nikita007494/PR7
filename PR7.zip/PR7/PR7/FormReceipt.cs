﻿using System;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace PR7
{
    public partial class FormReceipt : Form
    {
        private DatabaseHelper dbHelper;
        private int orderId;

        public FormReceipt(DatabaseHelper dbHelper, int orderId)
        {
            InitializeComponent();
            this.dbHelper = dbHelper;
            this.orderId = orderId;

            LoadReceiptData();
        }

        private void LoadReceiptData()
        {
            try
            {
                var order = dbHelper.GetOrderDetails(orderId);

                if (order != null)
                {
                    orderNumberLabel.Text = $"№ {order.Id}";
                    orderDateLabel.Text = order.OrderDate.ToString("dd.MM.yyyy HH:mm");
                    bookTitleLabel.Text = order.BookTitle;
                    customerNameLabel.Text = order.CustomerName;
                    officeLabel.Text = order.OfficeName;
                    priceLabel.Text = $"{order.Price:C}";

                    // Генерация текста для печати/сохранения
                    receiptTextBox.Text = GenerateReceiptText(order);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных чека: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GenerateReceiptText(Order order)
        {
            if (order == null) return "Нет данных о заказе";

            const int lineWidth = 40;

            // Форматируем данные (без ? для DateTime и decimal)
            string formattedDate = order.OrderDate.ToString("dd.MM.yyyy HH:mm");
            string customerName = order.CustomerName ?? "Клиент не указан";
            string bookTitle = order.BookTitle ?? "Издание не указано";
            string officeName = order.OfficeName ?? "Типография не указана";
            string price = order.Price.ToString("N2") + " ₽";

            StringBuilder receipt = new StringBuilder();

            // Заголовок
            receipt.AppendLine("".PadRight(lineWidth, '='));
            receipt.AppendLine(CenterText($"ЧЕК №{order.Id}", lineWidth));
            receipt.AppendLine("".PadRight(lineWidth, '='));

            // Дата
            receipt.AppendLine($"Дата: {formattedDate}");
            receipt.AppendLine("-".PadRight(lineWidth, '-'));

            // Клиент
            receipt.AppendLine($"Клиент: {customerName}");

            // Издание
            receipt.AppendLine($"Издание: {bookTitle}");

            // Типография
            receipt.AppendLine($"Типография: {officeName}");
            receipt.AppendLine("-".PadRight(lineWidth, '-'));

            // Стоимость
            receipt.AppendLine($"Стоимость: {price}");
            receipt.AppendLine("".PadRight(lineWidth, '='));

            // Подпись
            receipt.AppendLine(CenterText("Спасибо за заказ!", lineWidth));
            receipt.AppendLine(CenterText("Ожидайте уведомления.", lineWidth));
            receipt.AppendLine("".PadRight(lineWidth, '='));

            return receipt.ToString();
        }

        private string CenterText(string text, int width)
        {
            if (text.Length >= width) return text;

            int spaces = width - text.Length;
            int leftSpaces = spaces / 2;
            int rightSpaces = spaces - leftSpaces;

            return new string(' ', leftSpaces) + text + new string(' ', rightSpaces);
        }

        

        private string GetFormattedDate(DateTime? date)
        {
            if (!date.HasValue)
                return "Дата не указана";

            try
            {
                return date.Value.ToString("dd.MM.yyyy в HH:mm");
            }
            catch
            {
                return "Некорректная дата";
            }
        }

        private string GetFormattedPrice(decimal? price)
        {
            if (!price.HasValue)
                return "Цена не указана";

            try
            {
                return price.Value.ToString("N2", CultureInfo.GetCultureInfo("ru-RU")) + " ₽";
                // или используйте для валюты:
                // return price.Value.ToString("C", CultureInfo.GetCultureInfo("ru-RU"));
            }
            catch
            {
                return "Некорректная цена";
            }
        }

        private void printButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Здесь можно реализовать печать чека
                MessageBox.Show("Функция печати будет реализована позже", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при печати: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                saveDialog.Title = "Сохранить чек";
                saveDialog.FileName = $"чек_заказа_{orderId}.txt";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    System.IO.File.WriteAllText(saveDialog.FileName, receiptTextBox.Text);
                    MessageBox.Show("Чек успешно сохранен!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void receiptGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void receiptTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}